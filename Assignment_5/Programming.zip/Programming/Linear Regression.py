import pandas as pd                                
import numpy as np       
import matplotlib.pyplot as plt


data = pd.read_csv("numpydataset.csv")      # load the csv file as a DataFrame
data.head()                                 # displays the first 5 rows in the dataset


samples = len(data)              # calculating number of samples


def MSE(points, m, b):
    # write your code here...
    mse =0
    for i in range(0,len(points)):
        y = m*data.iloc[i,0] + b
        mse = mse + (pow(y-data.iloc[i,1],2))

    return mse/len(points)

    
    #return mean_sqaured_error


def gradient_descent(m_current, b_current, points, step_size):
    w = 0
    c=0

    # write your code here...
    for i in range(0,len(points)):
        y_pred = m_current*data.iloc[i,0] + b_current
        w = w + (-2*data.iloc[i,0]*(data.iloc[i,1]-y_pred))
        c = c + (-2*(data.iloc[i,1]-y_pred))
    
    m = m_current - (step_size*(w/samples))
    b = b_current - (step_size*(c/samples))

    return m,b
    
    #return m_new, b_new




m, b = 0, 0
L = 0.001       # initial learning rate, can be adjusted later
epochs = 100    # we iterate over the same dataset 100 times

for epoch in range(1, epochs+1):
    m, b = gradient_descent(m, b, data, L)
    loss = MSE(data, m, b)
    print(f"Epoch {epoch}, m: {m}, b:{b}, Loss: {loss}")
print(m, b, loss)



fig, ax = plt.subplots(1,1)

ax.scatter(data.Features, 
           data.Targets, 
           color="red", 
           linewidths=0.5, 
           label="Points")
ax.plot(data.Features, 
        [m * x + b for x in data.Features], 
        linewidth=3, 
        linestyle="dashed", 
        label="$ f(x) = mx+c $")

ax.legend(loc="lower right", bbox_to_anchor=(.96, 0.0))
ax.set_xlabel("Features")
ax.set_ylabel("Targets")

plt.savefig('LinearRegression001.png')

plt.close()


m, b = 0, 0
L = 0.01   # new learning rate
epochs = 100

for epoch in range(1, epochs+1):
    m, b = gradient_descent(m, b, data, L)
    loss = MSE(data, m, b)
    print(f"Epoch {epoch}, m: {m}, b:{b}, Loss: {loss}")
print(m, b, loss)



fig, ax = plt.subplots(1,1)

ax.scatter(data.Features, 
           data.Targets, 
           color="red", 
           linewidths=0.5, 
           label="Points")
ax.plot(data.Features, 
        [m * x + b for x in data.Features], 
        linewidth=3, 
        linestyle="dashed", 
        label="$ f(x) = mx+c $")

ax.legend(loc="lower right", bbox_to_anchor=(.96, 0.0))
ax.set_xlabel("Features")
ax.set_ylabel("Targets")

plt.savefig('LinearRegression01.png')
plt.close()

