#!/usr/bin/python
from PIL import Image, ImageStat
import numpy
import matplotlib.pyplot as plt
import random

# =========
# converged
# =========
#
# Will determine if the centroids have converged or not.
# Essentially, if the current centroids and the old centroids
# are virtually the same, then there is convergence.
#
# Absolute convergence may not be reached, due to oscillating
# centroids. So a given range has been implemented to observe
# if the comparisons are within a certain ballpark
#


def converged(centroids, old_centroids):
	if len(old_centroids) == 0:
		return False


	if len(centroids) <= 5:
		a = 1
	elif len(centroids) <= 10:
		a = 2
	else:
		a = 4

	for i in range(0, len(centroids)):
		cent = centroids[i]
		old_cent = old_centroids[i]

		if ((int(old_cent[0]) - a) <= cent[0] <= (int(old_cent[0]) + a)) and ((int(old_cent[1]) - a) <= cent[1] <= (int(old_cent[1]) + a)) and ((int(old_cent[2]) - a) <= cent[2] <= (int(old_cent[2]) + a)):
			continue
		else:
			return False

	return True

#end converged


# ======
# getMin
# ======
#
# Method used to find the closest centroid to the given pixel.
#
def getMin(pixel, centroids):
	minDist = 9999
	minIndex = 0

	for i in range(0, len(centroids)):
		d = numpy.sqrt(int((centroids[i][0] - pixel[0]))**2 + int((centroids[i][1] - pixel[1]))**2 + int((centroids[i][2] - pixel[2]))**2)
		if d < minDist:
			minDist = d
			minIndex = i

	return minIndex
#end getMin




# ============
# assignPixels
# ============
def assignPixels(centroids):
	clusters = {}

	for x in range(0, img_width):
		for y in range(0, img_height):
			p = px[x, y]
			minIndex = getMin(px[x, y], centroids)

			if minIndex in clusters.keys():
				clusters[minIndex].append(p)
			else:
				clusters[minIndex] = []
				clusters[minIndex].append(p)
	return clusters

#end assignPixels



# ===============
# adjustCentroids
# ===============

def adjustCentroids(clusters):
	new_centroids = []

	for k in sorted(clusters.keys()):
		n = numpy.mean(clusters[k], axis=0)
		new = (int(n[0]), int(n[1]), int(n[2]))
		print(str(k) + ": " + str(new))
		new_centroids.append(new)

	return new_centroids

#end adjustCentroids


# ===========
# initializeKmeans
# ===========
#
# Used to initialize the k-means clustering
#
def initializeKmeans(someK):
	centroids = []
	## Write your code here
	k =0 
	x = random.sample(range(0,img_width),someK)
	y = random.sample(range(0,img_height),someK)
	print(x)
	print(y)
	while k < someK:
		cent = px[x[k], y[k]]
		'''if cent in centroids:
			continue'''
		centroids.append(cent)
		k = k+1

	print("Centroids Initialized")
	print("===========================================")

	return centroids
#end initializeKmeans





# ===========
# iterateKmeans
# ===========
#
# Used to iterate the k-means clustering
#
def iterateKmeans(centroids):
	old_centroids = []
	it= 0
	print("Starting Assignments")
	print("===========================================")

	## Write your code here
	while not converged(centroids, old_centroids) and it <= 20:
		print("Iteration:" + str(it))
		it = it+ 1

		old_centroids = centroids 								
		clusters = assignPixels(centroids) 						
		centroids = adjustCentroids(clusters)
	print(clusters)
	print("===========================================")
	print("Convergence Reached!")
	return centroids
#end iterateKmeans


# ==========
# drawWindow
# ==========
#
# Once the k-means clustering is finished, this method
# generates the segmented image and opens it.
#
def drawWindow(result):
	img = Image.new('RGB', (img_width, img_height), "white")
	p = img.load()

	for x in range(img.size[0]):
		for y in range(img.size[1]):
			RGB_value = result[getMin(px[x, y], result)]
			p[x, y] = RGB_value

	img.show()

#end drawWindow
def get_dist(pixel,centroid):
	d = numpy.sqrt(int((centroid[0] - pixel[0]))**2 + int((centroid[1] - pixel[1]))**2 + int((centroid[2] - pixel[2]))**2)
	return d

def get_obj(clusters,centroids):
	obj = 0
	for key in clusters.keys():
		for p in clusters[key]:
			obj = obj + get_dist(p,centroids[key])

	return obj

def for_plots():
	lst = []
	ks = [k for k in range(20)]
	for k in range(20):
		initial_centroid=initializeKmeans(k+1)
		result = iterateKmeans(initial_centroid)
		clusters = assignPixels(result)
		lst.append(get_obj(clusters,result))

	plt.plot(ks, lst)
	plt.show()

def ran_in_plots(l,k):
	for i in range(l):
		initial_centroid=initializeKmeans(k)
		result = iterateKmeans(initial_centroid)
		drawWindow(result)


num_input = str(input("Enter image number: "))
k_input = int(input("Enter K value: "))

img = "img/test" + num_input.zfill(2) + ".jpg"
im = Image.open(img)
img_width, img_height = im.size
px = im.load()
initial_centroid=initializeKmeans(k_input)
result = iterateKmeans(initial_centroid)
drawWindow(result)
ran_in_plots(10,5)



